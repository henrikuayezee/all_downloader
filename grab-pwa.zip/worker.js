/**
 * Grab — CORS proxy.
 *
 * Deploy free on Cloudflare Workers, then paste the worker's address into
 * the app under "Connection".
 *
 * Usage:  https://your-worker.workers.dev/?url=<encoded twitter url>
 *
 * Only Twitter's own hosts are reachable through it, so it can't be turned
 * into an open proxy for the rest of the internet.
 */

const ALLOWED = [
  "cdn.syndication.twimg.com",
  "video.twimg.com",
  "pbs.twimg.com",
  "abs.twimg.com"
];

const CORS = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET, HEAD, OPTIONS",
  "access-control-allow-headers": "range, content-type",
  "access-control-expose-headers": "content-length, content-type, content-range, accept-ranges"
};

export default {
  async fetch(request) {
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: CORS });
    }
    if (request.method !== "GET" && request.method !== "HEAD") {
      return text(405, "Only GET and HEAD are supported.");
    }

    const target = new URL(request.url).searchParams.get("url");
    if (!target) return text(400, "Add ?url= followed by an encoded Twitter URL.");

    let parsed;
    try {
      parsed = new URL(target);
    } catch {
      return text(400, "That url parameter isn't a valid URL.");
    }
    if (parsed.protocol !== "https:") return text(400, "Only https URLs are allowed.");
    if (!ALLOWED.includes(parsed.hostname)) {
      return text(403, `${parsed.hostname} isn't on the allow list.`);
    }

    // Forward Range so the browser can resume or seek large files.
    const headers = { "user-agent": "Mozilla/5.0", "accept": "*/*" };
    const range = request.headers.get("range");
    if (range) headers.range = range;

    const upstream = await fetch(parsed.toString(), {
      method: request.method,
      headers,
      redirect: "follow"
    });

    const out = new Headers(upstream.headers);
    for (const [k, v] of Object.entries(CORS)) out.set(k, v);
    out.delete("set-cookie");
    out.delete("content-security-policy");

    return new Response(upstream.body, {
      status: upstream.status,
      statusText: upstream.statusText,
      headers: out
    });
  }
};

function text(status, message) {
  return new Response(message, {
    status,
    headers: { ...CORS, "content-type": "text/plain; charset=utf-8" }
  });
}
